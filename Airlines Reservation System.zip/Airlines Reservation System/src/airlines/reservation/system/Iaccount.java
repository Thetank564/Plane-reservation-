/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package airlines.reservation.system;

/**
 *
 * @author antho
 */
public interface Iaccount {

    public void printAllCurrentTickets(Account a);

    public void printTransactionHistory(Account a);

    public void removeTicketFromCurrentTickets(String ticket, Account a);

    public void downloadTicket(Ticket t) throws Exception;

    public void printAccountInfo();
}
