/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package airlines.reservation.system;

/**
 *
 * @author antho
 */
public class Transactions {
    String type;
    Ticket t;
    
    public Transactions(String type, Ticket t) {
        this.type = type;
        this.t = t;
    }

    @Override
    public String toString() {
        return type  + t ;
    }
    
    
}
